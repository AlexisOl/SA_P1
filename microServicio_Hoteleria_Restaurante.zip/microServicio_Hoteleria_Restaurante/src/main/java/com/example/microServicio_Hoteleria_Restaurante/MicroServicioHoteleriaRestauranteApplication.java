package com.example.microServicio_Hoteleria_Restaurante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServicioHoteleriaRestauranteApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioHoteleriaRestauranteApplication.class, args);
	}

}
