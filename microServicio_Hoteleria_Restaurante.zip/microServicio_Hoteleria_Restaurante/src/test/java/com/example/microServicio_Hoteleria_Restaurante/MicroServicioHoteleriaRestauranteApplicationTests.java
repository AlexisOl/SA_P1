package com.example.microServicio_Hoteleria_Restaurante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicioHoteleriaRestauranteApplicationTests {

	@Test
	void contextLoads() {
	}

}
