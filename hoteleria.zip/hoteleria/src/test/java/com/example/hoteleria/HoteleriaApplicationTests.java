package com.example.hoteleria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoteleriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
